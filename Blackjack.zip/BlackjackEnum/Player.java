import java.util.List;
import java.util.ArrayList;

public class Player
{
    private String name;
    private List<Card> hand;
    public Player(String name){
        this.name = name;
        this.hand = new ArrayList<Card>();
        
    }
    public String getName(){return name;}
    public List<Card> getHand(){return hand;}
    public void emptyHand(){
        while(hand.size()>0){
          hand.remove(0);  
        }
        
    }
    public int blackjackHandValue(){
        int sum = 0;
        for(Card c: hand){
            int temp = c.getValue();
            if(temp == 1){
                if(sum+11 <=21){
                    sum+=11;
                }
                else{sum+=1;}
            }
            else if(temp >=10){
                sum+=10;
            }
            else{sum+=c.getValue();}
        }
        for(int i = 0; i <hand.size();i++){
            int cardvalue = hand.get(i).getValue();
            if(sum > 21 && cardvalue == 1){
                sum-=10;
            }
        }
        return sum;
    }
    
    public void hitMe(Card c){
        hand.add(c);
    }
}
