import java.util.Stack;
import java.util.Iterator;
import java.util.Random;
public class Deck
{
    private Stack<Card> deck;

    public Deck(){
        deck = new Stack<Card>();
        Suit[] suits = Suit.values();
        Value[] values = Value.values();
        for(int i = 0; i < 4; i++){
            for(int v = 1; v < 14; v++){
                deck.push(new Card(values[v],suits[i]));
            }
        }
    }

    public Stack<Card> getDeck(){
        return deck;
    }

    public void printDeck(){
        Iterator<Card> itr = deck.iterator();
        while(itr.hasNext() == true){
            System.out.println(itr.next());
        }
    }

    public Card hit(){
        return deck.pop();
    }

    public void shuffle(){
        Stack<Card> pile1 = new Stack<Card>();
        Stack<Card> pile2 = new Stack<Card>();
        int numcards = deck.size();
        for(int w = 0; w<10; w++){
            for(int i = 0; i < numcards/2;i++){
                pile1.push(deck.pop());
            }
            while(deck.empty() == false){
                pile2.push(deck.pop());
            }
            Random rand = new Random();
            while(pile1.size() > 0 || pile2.size() >0){
                int slip = rand.nextInt(3)+1;
                for(int i = 0; i <slip; i++){
                    if(pile1.size()>0){
                        deck.push(pile1.pop());
                    }
                }
                slip = rand.nextInt(3)+1;
                for(int i = 0; i <slip; i++){
                    if(pile2.size()>0){
                        deck.push(pile2.pop());
                    }
                }
            }
        }
    }
}
