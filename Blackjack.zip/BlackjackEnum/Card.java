
public class Card
{
    private Value value;
    private Suit suit;
    public Card(Value value, Suit suit){
       this.value = value;
       this.suit = suit;
    }

    public int getValue(){
        return value.getValue();
    }

    public String getSuit(){
        return suit.getSuit();
    }
    
    @Override
    public String toString(){
        return ""+value +" of " +suit;
    }
}
