import java.util.Random;
import java.util.Scanner;
public class Blackjack
{
    public static void main(String[] Args){
        int playerwon = 0;
        int dealerwon = 0;
        boolean playing = true;
        Deck deck = new Deck();
        Scanner scan = new Scanner(System.in);
        System.out.println("Welcome to Blackjack! Please enter your name.");
        String name = scan.nextLine();
        Player player = new Player(name);
        Player computer = new Player("Dealer");
        while(playing){
            boolean playerturn = true;
            boolean computerturn = true;
            deck.shuffle();
            for(int i = 0; i < 2; i++){
                player.hitMe(deck.hit());
                computer.hitMe(deck.hit());
            }
            if(player.blackjackHandValue() == 21){
                playerturn = false;
                System.out.println("Your hand is: " +player.getHand());
                System.out.println("--You have Blackjack!!!");
                playerwon++;
            }
            else{
                System.out.println("Your hand is: " +player.getHand());
                System.out.println("--Your hand value is: "+player.blackjackHandValue());
                while(playerturn){
                    
                    System.out.println("--Would you like to hit or stay?");
                    String choice = scan.nextLine();
                    if(choice.equals("stay")){
                        playerturn = false;
                    }
                    else if(choice.equals("hit")){
                        player.hitMe(deck.hit());
                        System.out.println("Your hand is: "+player.getHand());
                                        System.out.println("--Your hand value is now: "+player.blackjackHandValue());
                        if(player.blackjackHandValue() >21){
                            System.out.println("--You have bust! :(");
                            playerturn = false;
                        }
                    }
                    else{
                        System.out.println("--Please enter a valid response.");
                    }
                }
                while(computerturn){
                    if(computer.blackjackHandValue()<16){
                        computer.hitMe(deck.hit());
                    }
                    else{computerturn = false;}
                    if(computer.blackjackHandValue() >21){
                        computerturn = false;
                    }
                }
                System.out.println("Your hand is: "+player.getHand());
                System.out.println("--Your hand value is: "+player.blackjackHandValue());
                System.out.println("The dealer's hand is: "+computer.getHand());
                System.out.println("--The dealer's hand value is: "+computer.blackjackHandValue());
                if((player.blackjackHandValue()> computer.blackjackHandValue() && player.blackjackHandValue() <=21)|| computer.blackjackHandValue() > 21 && player.blackjackHandValue()<=21){
                    System.out.println("--"+name+" won this round!!!");
                    playerwon++;
                }
                else{
                    System.out.println("--The dealer has won this round!!!");
                    dealerwon++;
                }
            }
            System.out.println("--you have won " + playerwon + " rounds");
            System.out.println("--the dealer has won " + dealerwon + " rounds");
            System.out.println("--Would you like to play again? y or n");
            String isplaying = scan.nextLine();
            if(isplaying.equals("n")){
                System.out.println("--Thanks for playing!");
                playing = false;
            }
            if(isplaying.equals("y")){
                player.emptyHand();
                computer.emptyHand();
            }
        }
    }
}
