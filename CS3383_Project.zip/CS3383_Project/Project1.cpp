﻿/*---Group 13---
Kasandra Gloria
Destiny Lopez
Ashley Okungu
Nicholas Richard
*/
#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <cctype>
#include <set>
#include <vector>
using namespace std;
//storage for beta tuple
vector<string> betaS;
//transition storage
struct Transition {//reads 3 at a time
    string from;//starting state
    char symbol;//push back alphabet
    string to;//finishing state
};
struct alpha//the tuple for the nfa
{
    
    set<char> alphabet;
    set<string> states;
    string start;
    set<string> finalS;
    vector<Transition> transitions;

};
//function for accepting the string
//basically what you had in the main function
bool pass(alpha a1, string input)
{
    set<string> currentStates;
    currentStates.insert(a1.start);
    //starts with starting state being the current state
    for (char sym : input) {// for each character from the input it will find the transition that matches
                set<string> nextStates;
                for (string s : currentStates) {
                    for (auto& trans : a1.transitions) {
                        //if it matches a state it moves to the next state
                        if (trans.from == s && trans.symbol == sym) {
                            nextStates.insert(trans.to);
                        }
                    }
                }
                currentStates = nextStates;
            }
            //after string is processed, will check if the current state is the final state
    for(string s : currentStates)
    {
        if(a1.finalS.count(s))
        {
            //if final state
            return true;
        }
    }
    //if not final state
    return false;

}
alpha parsing(string filee)
{
    ifstream file(filee);
    if(!file) //checks if file can be opened this is good practice
    {
        cout << "File cannot be opened." <<endl;
        exit(1);
    }

    alpha nfa;
    vector<string> tokens;
    string word;
    //will go through the file word by word 
    while(file >> word)
    {
        string clean = "";
        //will remove any non token(i.e. spaces, parenthesis, commas)
        for (char c : word) {
        if (isalnum(c)) {
            clean += c;
        }
        else{
            if(!clean.empty())
            {
                tokens.push_back(clean);
                clean = "";
            }
        }
    }
    if(!clean.empty())
    {
        tokens.push_back(clean);
    }
    }
    //keeps track of token placement
    int i = 0;
    //reads the alphabet (assuming the max is 50)until it reaches first state by reading 'q'
    while (i < tokens.size() && tokens[i][0] != 'q') {
        nfa.alphabet.insert(tokens[i][0]);
        i++;
    }
    //reads the states and skips any repeated states
    while (i < tokens.size() && tokens[i][0] == 'q') {
        if (nfa.states.count(tokens[i])) {
            break;
        }

        nfa.states.insert(tokens[i]);
        i++;
    }

    //reads starting state
    nfa.start = tokens[i++];
    //reads final state
    nfa.finalS.insert(tokens[i++]);
    while((i+2) < tokens.size())
    {
        //each state has 3 transitions: from, symbol, to
        Transition st;
        string from = tokens[i];
        string symbol = tokens[i+1];
        string to = tokens[i+2];
        //checks if inside the parentheses looks like a state
        //if yes it will store it
        if(from[0] == 'q' && to[0] == 'q')
        {
            st.from = from;
            st.symbol = symbol[0];
            st.to = to;
            nfa.transitions.push_back(st);
            i+=3;
        }
        //if no it will break because it would have reached beta
        else{
            break;
        }
        
    }
    //anything left after the transitions will be stored in the beta tuple
    while (i < tokens.size()) {
        betaS.push_back(tokens[i]);
        i++;
    }
    
    return nfa;

    

}


int main()
{
    string fileName;
    string input;
    fstream myFile;

    cout << "Please input the file name: ";
    cin >> fileName;

    alpha al = parsing(fileName);
    cin.ignore();
    //checks if beta is not empty
    if (!betaS.empty()) {
        cout << "(";

        for (int i = 0; i < betaS.size(); i++) {
            if (pass(al, betaS[i])) {
                cout << "accepted";
            } else {
                cout << "rejected";
            }

            if (i != betaS.size() - 1) {
                cout << ", ";
            }
        }

        cout << ")" << endl;
        return 0;
    }
        // main loop
        //gets user input if beta is empty
        while (true) {
            cout << "Please input a string: ";
            getline(cin, input);

            if (input == "") {
                cout << "Bye Bye." << endl;
                break;
            }
            if(pass(al, input))
            {
                cout << "Accepted." << endl;
            }
            else
            {
                cout << "Rejected." << endl;
            }
            

    }
    myFile.close();
    return 0;
}
