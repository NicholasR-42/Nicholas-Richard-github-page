Kasandra Gloria, Destiny Lopez, Ashley Okungu, Nicholas Richard - Group 13

The software used was Visual Studio Code and Visual Studio on Windows. 
The programming language used was C++.

How to compile and run on Windows:
	//Make sure both the project code and the test files are in the same folder.
	1. Open Command Line on Windows
	2. Go to folder path: cd "path name"
	//you can check if files are in the same folder typing "dir" in cmd window
	3. Compile the program using "g++ Project1.cpp -o project1"
	4. Run the program with "project.exe"


