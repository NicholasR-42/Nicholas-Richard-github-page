import java.net.ServerSocket;
import java.net.Socket;
import java.net.InetAddress;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.OutputStreamWriter;
import java.util.Scanner;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Client implements ActionListener
{
    private static Socket socket;
    private static JTextArea displayArea, userListArea;
    private static JTextField messageField;
    public static void main (String[]args)throws Exception{
        System.out.println("Client MAIN METHOD");
        String myIP = InetAddress.getLocalHost().getHostAddress();
        int myPort = 50000;

        Scanner scan = new Scanner(System.in);
        System.out.print("ENTER IP TO CONNECT TO: ");
        String theirIP = scan.nextLine();
        System.out.print("ENTER PORT TO CONNECT TO: ");
        int theirPort = scan.nextInt(); scan.nextLine();
        System.out.println("PLEASE ENTER A USERNAME");
        String username = scan.nextLine();
        System.out.println("TRYING TO CONNECT TO THE SERVER...");
        socket = new Socket(theirIP, theirPort);
        System.out.println("...SUCCESSFULLY JOINED THE SERVER!");

        sendMessage(username);
        new Client();
        Thread talkThread = new Thread(new TalkThread());
        Thread listenThread = new Thread(new ListenThread());
        talkThread.start();
        listenThread.start();

        

        while(true){}
    }

    public Client(){
        JFrame frame = new JFrame("Chat Application");
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout()); 

        //create components
        int vsb = ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS;
        int hsb = ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS;
        Font font = new Font("Times New Roman", Font.PLAIN, 40);

        displayArea = new JTextArea();
        displayArea.setFont(font);
        JScrollPane displayPane = new JScrollPane(displayArea,vsb,hsb);
        displayPane.setPreferredSize(new Dimension(750,700));
        userListArea = new JTextArea();
        JScrollPane userListPane = new JScrollPane(userListArea,vsb,hsb);
        userListArea.setFont(font);
        userListPane.setPreferredSize(new Dimension(250,700));
        
        //userListArea.setEnabeled(false);
        messageField = new JTextField("");
        messageField.setFont(font);
        messageField.setPreferredSize(new Dimension(1000,100));

        //add components to panel
        panel.add(displayPane, BorderLayout.CENTER);
        panel.add(userListPane, BorderLayout.WEST);
        panel.add(messageField, BorderLayout.SOUTH);

        //final frame settings
        frame.add(panel);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setAlwaysOnTop(true);
        frame.setAlwaysOnTop(false);
        //message field actions
        messageField.addActionListener(this);
        messageField.grabFocus();
        messageField.requestFocus();
    }

    public void actionPerformed(ActionEvent e){
        try{
            String message = messageField.getText();
            messageField.setText("");
            sendMessage(message);
        }
        catch(Exception err){
            err.printStackTrace();   
        }
    }

    public static void sendMessage(String message){
        try{
            OutputStreamWriter osw = new OutputStreamWriter(socket.getOutputStream());
            PrintWriter pw = new PrintWriter(osw, true);
            pw.println(message);
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    private static class TalkThread implements Runnable{
        public void run(){
            try{
                System.out.println("TALK THREAD STARTED!");
                OutputStreamWriter osw = new OutputStreamWriter(socket.getOutputStream());
                PrintWriter pw = new PrintWriter(osw, true);
                Scanner scan = new Scanner(System.in);
                while(socket.isClosed() == false){
                    String message = scan.nextLine();
                    pw.println(message);
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
    }

    private static class ListenThread implements Runnable{
        public void run(){
            try{
                System.out.println("LISTEN THREAD STARTED!");
                InputStreamReader isr = new InputStreamReader(socket.getInputStream());
                BufferedReader br = new BufferedReader(isr);
                while(socket.isClosed() == false){
                    String message = br.readLine();
                    if(message.startsWith("USERS")){
                        message = message.replaceAll("_","\n");
                        userListArea.setText(message);
                    }
                    else{
                        System.out.println(message);
                        displayArea.append(message+"\n");
                    }
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
    }
}

