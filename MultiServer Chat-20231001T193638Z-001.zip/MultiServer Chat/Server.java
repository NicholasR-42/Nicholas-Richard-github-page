import java.net.ServerSocket;
import java.net.Socket;
import java.net.InetAddress;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.OutputStreamWriter;
import java.util.Scanner;
import java.util.LinkedHashSet;
import java.util.Set;
public class Server
{
    private static Set<ClientData> clients;
    public static void main (String[]args)throws Exception{
        System.out.println("SERVER MAIN");
        clients = new LinkedHashSet<ClientData>();
        Thread acceptThread = new Thread(new AcceptThread());
        acceptThread.start();
        Thread talkThread = new Thread(new TalkThread());
        talkThread.start();
        while(true){}
    }

    public static void broadcast(String message){
        for(ClientData c : clients){
            c.getPW().println(message);  
        }
    }

    public static String getUsers(){
        String users = "USERS_";
        for(ClientData d : clients){
            users+=d.getUsername()+"_";
        }
        return users;
    }

    private static class AcceptThread implements Runnable{
        public void run(){
            try{
                String myIP = InetAddress.getLocalHost().getHostAddress();
                int myPort = 50001;
                ServerSocket serverSocket = new ServerSocket(myPort);
                System.out.println("HOSTING SERVER IN " +myIP+":" + myPort);
                while(serverSocket.isClosed() == false){
                    System.out.println("WAITING FOR CONNECTION...");
                    Socket socket = serverSocket.accept();

                    InputStreamReader isr = new InputStreamReader(socket.getInputStream());
                    BufferedReader br = new BufferedReader(isr);
                    String username = br.readLine();
                    ClientData c = new ClientData(socket, username);

                    clients.add(c);
                    broadcast(getUsers());
                    Thread listenThread = new Thread(new ListenThread(c));
                    listenThread.start();
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
    }

    private static class TalkThread implements Runnable{
        public void run(){
            try{
                System.out.println("TALK THREAD STARTED!");
                Scanner scan = new Scanner(System.in);
                while(true){
                    String message = scan.nextLine();
                    broadcast("[SERVER]: "+message);
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
    }

    private static class ListenThread implements Runnable{
        private Socket socket;
        private String username;
        private ClientData c;
        public ListenThread(ClientData c){
            socket = c.getSocket();
            username = c.getUsername();
            this.c = c;
        }

        public void run(){
            try{
                System.out.println("LISTEN THREAD STARTED!");
                InputStreamReader isr = new InputStreamReader(socket.getInputStream());
                BufferedReader br = new BufferedReader(isr);
                while(socket.isClosed() == false){
                    String message = br.readLine();
                    System.out.println("[" + username+"]: "+message);
                    broadcast("[" + username+"]: "+message);
                }
            }
            catch(Exception e){
                clients.remove(c);
                broadcast(getUsers());
            }
        }
    }

    private static class ClientData{
        private Socket socket;
        private String username;
        private BufferedReader br;
        private PrintWriter pw;
        public ClientData(Socket socket, String username){
            try{
                this.socket = socket;
                this.username = username;
                InputStreamReader isr = new InputStreamReader(socket.getInputStream());
                this.br = new BufferedReader(isr);
                OutputStreamWriter osw = new OutputStreamWriter(socket.getOutputStream());
                this.pw = new PrintWriter(osw, true);
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }

        public Socket getSocket(){
            return this.socket;
        }

        public String getUsername(){
            return this.username;
        }

        public BufferedReader getBR(){
            return this.br;
        }

        public PrintWriter getPW(){
            return this.pw;
        }
    }
}
