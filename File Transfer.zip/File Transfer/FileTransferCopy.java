
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.Socket;

public class FileTransferCopy {
    public static void main(String[] argv) throws Exception {
        Socket sock = new Socket("10.230.143.6", 50000);

        InputStream is = sock.getInputStream();
        FileOutputStream fos = new FileOutputStream("new file.jpg");
        BufferedOutputStream bos = new BufferedOutputStream(fos);
        byte[] myByteArray = new byte[20480];
        int bytesRead = is.read(myByteArray, 0, myByteArray.length);

        bos.write(myByteArray, 0, bytesRead);
        bos.close();
        sock.close();
        
        
        //api for inputStream, fileOutputStream, fileChannel for better code
    }
}